﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApp1
{
    internal class Zametka
    {
        public string name;
        public string description;
        public string data;
        public int position;
    }
}
