﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp1
{
    public partial class Page1 : Page
    {
        private string selectedDate;
        private int selectedDayIndex;

        public Page1(string date)
        {
            InitializeComponent();
            selectedDate = date;
        }

        private void DatePicker_Loaded(object sender, RoutedEventArgs e)
        {
            DatePicker.Text = selectedDate;
        }

        private void Back_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = Window.GetWindow(this) as MainWindow;
            mainWindow.ContentFrame.Content = null;
            mainWindow.Visibility = Visibility.Visible;
        }




        public void SetSelectedDayIndex(int dayIndex)
        {
            selectedDayIndex = dayIndex;
        }

        private void BackadSave_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = Window.GetWindow(this) as MainWindow;
            mainWindow.ContentFrame.Content = null;
            mainWindow.Visibility = Visibility.Visible;
        }
    }
}
