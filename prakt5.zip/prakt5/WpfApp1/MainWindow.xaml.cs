﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Globalization;

namespace WpfApp1
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            Data.SelectedDateChanged += Data_SelectedDateChanged; // Добавляем обработчик события SelectedDateChanged
            Data.Text = DateTime.Now.ToString("dd.MM.yyyy");
            UpdateDayControls();
        }

        private void MonthBack_Click(object sender, RoutedEventArgs e)
        {
            if (Data.SelectedDate.HasValue)
            {
                DateTime currentSelectedDate = Data.SelectedDate.Value;
                DateTime newSelectedDate = currentSelectedDate.AddMonths(-1);
                Data.SelectedDate = newSelectedDate;
                UpdateDayControls();
            }
        }

        private void MontNext_Click(object sender, RoutedEventArgs e)
        {
            if (Data.SelectedDate.HasValue)
            {
                DateTime currentSelectedDate = Data.SelectedDate.Value;
                DateTime newSelectedDate = currentSelectedDate.AddMonths(1);
                Data.SelectedDate = newSelectedDate;
                UpdateDayControls();
            }
        }

        private void UpdateDayControls()
        {
            dayControlsPanel.Children.Clear();

            if (Data.SelectedDate.HasValue)
            {
                DateTime selectedDate = Data.SelectedDate.Value;
                int daysInMonth = DateTime.DaysInMonth(selectedDate.Year, selectedDate.Month);

                for (int day = 1; day <= daysInMonth; day++)
                {
                    UserControl1 dayControl = new UserControl1();
                    dayControl.Number.Content = day.ToString();
                    dayControl.Margin = new Thickness(5);
                    dayControl.MouseUp += DayControl_MouseUp; // Добавляем обработчик события MouseUp
                    dayControlsPanel.Children.Add(dayControl);
                }
            }
        }

        private void Data_SelectedDateChanged(object sender, SelectionChangedEventArgs e)
        {
            UpdateDayControls();
        }

        private void DayControl_MouseUp(object sender, MouseButtonEventArgs e)
        {
            int selectedDayIndex = dayControlsPanel.Children.IndexOf((UserControl1)sender);
            string selectedDate = Data.Text;
            DateTime parsedDate;
            if (DateTime.TryParseExact(selectedDate, "dd.MM.yyyy", CultureInfo.InvariantCulture, DateTimeStyles.None, out parsedDate))
            {
                DateTime modifiedDate = new DateTime(parsedDate.Year, parsedDate.Month, selectedDayIndex + 1);
                string formattedDate = modifiedDate.ToString("dd.MM.yyyy");

                Page1 page1 = new Page1(formattedDate);
                page1.SetSelectedDayIndex(selectedDayIndex);

                ContentFrame.Content = page1;
            }
        }




    }
}
